# app/binance_api.py

from __future__ import annotations
from abc import ABC, abstractmethod

from binance.client import Client
from binance.exceptions import BinanceAPIException
from ..config import BINANCE_API_KEY, BINANCE_API_SECRET  # якщо виникне ImportError -> заміни на: from .config import ...
from binance_api import BinanceAPI

import pandas as pd
import numpy as np
from typing import List, Any, Optional, Dict


# Ініціалізація клієнта на модульному рівні (опційно)
client = Client(BINANCE_API_KEY, BINANCE_API_SECRET)



class MarketDataSource(ABC):
    @abstractmethod
    def get_ohlcv(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        pass

    @abstractmethod
    def get_orderbook_imbalance(self, symbol: str) -> float:
        pass

    @abstractmethod
    def get_top_traders_ratio(self, symbol: str) -> float:
        pass

class BinanceData(MarketDataSource):
    def __init__(self, depth_limit: int = 20):
        self.api = BinanceAPI()
        self.depth_limit = depth_limit

    def get_ohlcv(self, symbol: str, timeframe: str, limit: int = 500) -> pd.DataFrame:
        return self.api.get_ohlcv(symbol=symbol, interval=timeframe, limit=limit)

    def get_orderbook_imbalance(self, symbol: str) -> float:
        depth = self.api.get_order_book(symbol=symbol, limit=self.depth_limit)
        if not depth or "bids" not in depth or "asks" not in depth:
            return 0.0
        try:
            bid_qty = sum(float(qty) for _, qty in depth["bids"])
            ask_qty = sum(float(qty) for _, qty in depth["asks"])
            denom = bid_qty + ask_qty
            if denom <= 0:
                return 0.0
            return float(np.clip((bid_qty - ask_qty) / denom, -1.0, 1.0))
        except Exception:
            return 0.0


class BinanceAPI:
    """
    Обгортка над python-binance для нашого проєкту.
    - get_klines: сирі дані зі Spot API (як повертає Binance).
    - get_ohlcv: DataFrame зі стовпцями ts/open/high/low/close/volume для Smart Money.
    - get_order_book: топ книги заявок.
    - place_limit_order/cancel_order: базові операції.
    """

    def __init__(self) -> None:
        self.client = Client(BINANCE_API_KEY, BINANCE_API_SECRET)

    # ------------------------
    # Ринкові дані
    # ------------------------
    def get_klines(self, symbol: str, interval: str = "5m", limit: int = 100) -> List[List[Any]]:
        """
        Повертає сирий список списків з Binance (див. офіційну схему Klines).
        0 Open time(ms), 1 Open, 2 High, 3 Low, 4 Close, 5 Volume, 6 Close time(ms), ...
        """
        try:
            return self.client.get_klines(
                symbol=symbol.upper(),
                interval=interval,
                limit=limit
            )
        except BinanceAPIException as e:
            print(f"[BINANCE ERROR] get_klines: {e}")
            return []
        except Exception as e:
            print(f"[UNKNOWN ERROR] get_klines: {e}")
            return []

    def get_ohlcv(self, symbol: str, interval: str = "5m", limit: int = 100) -> pd.DataFrame:
        """
        Повертає OHLCV у вигляді DataFrame з колонками:
        ts (ms), open, high, low, close, volume (float)
        — саме такий формат очікує SmartMoneyEngine.
        """
        raw = self.get_klines(symbol=symbol, interval=interval, limit=limit)
        if not raw:
            return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])

        # Схема колонок згідно Binance docs:
        # https://binance-docs.github.io/apidocs/spot/en/#kline-candlestick-data
        cols = [
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "qav", "num_trades", "taker_base_vol", "taker_quote_vol", "ignore"
        ]
        try:
            df = pd.DataFrame(raw, columns=cols)
        except Exception:
            # На випадок, якщо бібліотека повернула інший формат
            df = pd.DataFrame(raw)
            df = df.iloc[:, :6]
            df.columns = ["open_time", "open", "high", "low", "close", "volume"]

        df = df[["open_time", "open", "high", "low", "close", "volume"]].copy()

        # Конвертації типів
        # Binance віддає open_time у мілісекундах; збережемо як int64 у колонку ts
        df["ts"] = pd.to_numeric(df["open_time"], errors="coerce").astype("Int64")
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")

        df = df[["ts", "open", "high", "low", "close", "volume"]].dropna().sort_values("ts").reset_index(drop=True)
        # Приведемо ts до int (може бути pandas NA тип)
        if df["ts"].dtype.name != "int64":
            df["ts"] = df["ts"].astype("int64")

        return df

    def get_order_book(self, symbol: str, limit: int = 5) -> Optional[Dict[str, List[List[str]]]]:
        """Отримати верхню частину книги заявок (bids/asks)."""
        try:
            depth = self.client.get_order_book(symbol=symbol.upper(), limit=limit)
            return depth
        except BinanceAPIException as e:
            print(f"[BINANCE ERROR] get_order_book: {e}")
            return None
        except Exception as e:
            print(f"[UNKNOWN ERROR] get_order_book: {e}")
            return None

    # ------------------------
    # Торгівля
    # ------------------------
    def place_limit_order(self, symbol: str, side: str, quantity: float, price: float) -> Optional[dict]:
        """Виставити лімітний ордер (BUY/SELL)."""
        try:
            order = self.client.create_order(
                symbol=symbol.upper(),
                side=side,
                type="LIMIT",
                timeInForce="GTC",
                quantity=quantity,
                price=str(price)
            )
            return order
        except BinanceAPIException as e:
            print(f"[BINANCE ERROR] place_limit_order: {e}")
            return None
        except Exception as e:
            print(f"[UNKNOWN ERROR] place_limit_order: {e}")
            return None

    def cancel_order(self, symbol: str, order_id: str) -> Optional[dict]:
        """Скасувати ордер за ID."""
        try:
            result = self.client.cancel_order(symbol=symbol.upper(), orderId=order_id)
            return result
        except BinanceAPIException as e:
            print(f"[BINANCE ERROR] cancel_order: {e}")
            return None
        except Exception as e:
            print(f"[UNKNOWN ERROR] cancel_order: {e}")
            return None
